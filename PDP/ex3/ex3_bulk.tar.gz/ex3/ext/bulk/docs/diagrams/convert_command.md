convert -density 150 -flatten -trim  -sharpen 0x1.0 -resize 500% -quality 100 -geometry 500x variable.pdf variable.png
