# `bulk::coarray::operator()`

```cpp
image operator()(int t);
```

Obtain an object encapsulating the image of the coarray.

## Parameters

* `t` - the image index
