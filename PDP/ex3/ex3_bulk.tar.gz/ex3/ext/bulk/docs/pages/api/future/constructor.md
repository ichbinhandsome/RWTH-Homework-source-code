# `bulk::future::future`

```cpp
future(world& world);
```

Constructs a message future for use in `world`.

## Parameters

* `world` - the world this future belongs to
