# `bulk::future::~future`

```cpp
~future();
```

Deconstructs a future and invalidates its buffer.
