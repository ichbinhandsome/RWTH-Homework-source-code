# `bulk::future::world`

```cpp
bulk::world& world();
```

Returns a reference to the world the future belongs to

## Return value

- A reference to the world.
