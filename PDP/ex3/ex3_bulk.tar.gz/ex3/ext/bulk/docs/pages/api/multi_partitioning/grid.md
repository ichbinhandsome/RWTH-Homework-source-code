# `bulk::multi_partitioning::grid`

```cpp
index_type<G> grid();
```

Returns the processor grid space.

## Return value

- `index_type<G>`: The shape of the processor grid.
