# `bulk::partitioning::partitioning`

```cpp
partitioning(index_type<D> global_size);
```

Constructs a partitioning.

## Parameters

* `global_size` - the shape of the data
