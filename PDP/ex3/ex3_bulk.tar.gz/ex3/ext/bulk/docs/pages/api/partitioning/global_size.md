# `bulk::partitioning::global_size`

```cpp
index_type<D> global_size() const;
```

Returns the data space shape.

## Return value

- `index_type<D>`: The shape of the data space.
