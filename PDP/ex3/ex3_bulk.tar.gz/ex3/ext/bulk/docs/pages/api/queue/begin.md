# `bulk::queue::begin`

```cpp
iterator begin();
```

Obtain an iterator to the begin of the local queue.

## Return value

- an iterator to the begin of the local queue
