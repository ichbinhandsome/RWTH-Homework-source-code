# `bulk::queue::end`

```cpp
iterator end();
```

Obtain an iterator to the end of the local queue.

## Return value

- an iterator to the end of the local queue
