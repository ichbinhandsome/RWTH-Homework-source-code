# `bulk::queue::size`

```cpp
size_t size() const;
```

Obtain the number of messages in the local queue.

## Return value

- the number of messages in the local queue
