# `bulk::queue::world`

```cpp
bulk::world& world();
```

Returns a reference to the world the queue belongs to

## Return value

- A reference to the world.
