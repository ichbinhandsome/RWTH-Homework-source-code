# `bulk::var::~var`

```cpp
~var();
```

Deconstructs a variable and deregisters it with its `world`.

## Complexity and cost

* **Cost** - `l` or free, depending on the backend
