# `bulk::var::operator()`

```cpp
image operator()(int t);
```

Obtain an image object, used to communicate with a remote image.

## Parameters

* `t` - the id of the remote processor
