# `bulk::world::barrier`

```cpp
void barrier() const;
```

Performs a global barrier of the active processors.

## Complexity and cost

* **Cost** - `l` (approximately)
