# `bulk::world::prev_rank`

```cpp
int prev_rank() const;
```

Returns the id of the previous logical processor.

## Return value

- `int`: The id of the previous processor
