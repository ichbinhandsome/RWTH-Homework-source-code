#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <sys/time.h>
#include <bulk/bulk.hpp>
#include <bulk/backends/mpi/mpi.hpp>
#include <iostream>

#define DEFAULT_K 5
#define DEFAULT_NITERS 20

struct point_t {
  double x;
  double y;
};

double get_time() {
  struct timeval tv;
  gettimeofday(&tv, (struct timezone *)0);
  return ((double)tv.tv_sec + (double)tv.tv_usec / 1000000.0);
}

void read_points(std::string filename, bulk::partitioned_array<point_t,1,1>& p, int n, int displacement) {
  std::ifstream infile{filename};
  double x, y;
  int i = 0;
  // go to the line of the file indicated by displacement and read n values
  infile.seekg(std::ios::beg);
  for (int currLineNumber = 0; currLineNumber < displacement; ++currLineNumber)
      infile.ignore(std::numeric_limits<std::streamsize>::max(), infile.widen('\n'));

  while (infile >> x >> y) {
    if (i >= n) {
        break;
    }
    p.local({i}).x = x;
    p.local({i}).y = y;
    i++;
  }
}

void write_result(std::string filename, int niters, point_t *result, int k) {
  std::ofstream outfile{filename};
  for (int iter = 0; iter < niters + 1; ++iter) {
    for (int i = 0; i < k; ++i) {
      outfile << iter << ' ' << result[iter * k + i].x << ' '
              << result[iter * k + i].y << '\n';
    }
  }
}

void init_centroids(bulk::coarray<point_t> &centroids, int k, int numprocs) {
  for (int i = 0; i < k; ++i) {
      double x = rand() % 100;
      double y = rand() % 100;
      for (int t = 0; t < numprocs; ++t) {
          centroids(t)[i] = {x, y};
      }
  }
}

double euclid_dist(point_t p, point_t q) {
    return ((p.x - q.x) * (p.x - q.x))
                + ((p.y - q.y) * (p.y - q.y)) ;
}

template<typename T, typename Func>
void reduce_coarray(bulk::coarray<T>& coarray, Func f, int size, int root, bulk::world& world) {
    std::vector<bulk::future<T[]>> futcounts; 
    if (world.rank() == root) {
        for (int p = 0; p < world.active_processors(); ++p) {
            if (p != root)
                futcounts.push_back(coarray(p)[{0, size}].get());
        }
    }

    world.sync();

    if (world.rank() == root) {
        for (auto it = futcounts.begin(); it != futcounts.end(); ++it) {
            for (int i = 0; i < size; ++i) {
                f(coarray[i], (*it)[i]);
            }
        }
    }
}

// Implement the k-means algorithm
void k_means(int niters,
             bulk::partitioned_array<point_t,1,1>& points,
             bulk::coarray<point_t> &centroids,
             point_t *result, 
             int local_size,
             int k,
             bulk::world& world) {
    auto myrank = world.rank();
    auto numprocs = world.active_processors();

    for (int iter = 0; iter < niters; ++iter) {
        // TODO: assignment step (locally)
        
        // TODO: sum up counts and assignment sum values (locally)

        // TODO: communicate counts and assignment sum values

        // TODO: update step: recalculate new centroids, broadcast new centroids
    }
}

int main(int argc, const char *argv[]) {
  // Handle input arguments
  if (argc < 3 || argc > 5) {
    printf("Usage: %s <input file> <num points> <num centroids> <num iters>\n",
           argv[0]);
    return EXIT_FAILURE;
  }
  const char *input_file = argv[1];
  const int n = atoi(argv[2]);
  const int k = (argc > 3 ? atoi(argv[3]) : DEFAULT_K);
  const int niters = (argc > 4 ? atoi(argv[4]) : DEFAULT_NITERS);

  // Spawn SPMD block
  bulk::mpi::environment env;
  env.spawn(env.available_processors(), [n,k,niters,input_file](auto &world) {
      // Get own ranks and number of processors
      int myrank = world.rank();
      int numprocs = world.active_processors();

      // Simple block partitioning of points, the points are parsed later
      // on from the given input file in a distributed way.
      bulk::block_partitioning<1,1> part({n}, {world.active_processors()});

      // Allocate partitioned array for points
      bulk::partitioned_array<point_t,1,1> points(world, part);

      // Get local size of array and position in global index space
      auto local_size = part.local_size(myrank)[0];
      auto displacement = part.global({0}, myrank)[0];

      // Every processor reads a certain part of the input file
      read_points(input_file, points, local_size, displacement);

      // Centroids are stored in a coarray
      bulk::coarray<point_t> centroids(world, k);

      // Rank 0 initiates centroids and broadcasts them to ALL ranks
      if (world.rank() == 0) {
          srand(1234);
          init_centroids(centroids, k, numprocs);
      }

      world.sync(); // Centroids now available at all ranks

      // Result vector, only allocated and initialized locally at rank 0
      point_t *result = nullptr;
      if (myrank == 0) {
          result = static_cast<point_t *>(malloc((niters + 1) * k * sizeof(point_t)));
          // Rest initialized with -1
          for (int i = 0; i < (niters + 1) * k; ++i) {
              result[i].x = -1.0;
              result[i].y = -1.0;
          }

          // First result vector
          for (int i = 0; i < k; ++i) {
              result[i].x = centroids[i].x;
              result[i].y = centroids[i].y;
          }
      }

      // TODO: Allocate and initialize rest of required arrays / coarrays 


      if (world.rank() == 0) {
          world.log("Running with %d processes...", numprocs);
          world.log("Executing k-means clustering with %d iterations, %d points, and %d "
         "centroids...\n", niters, n, k);
      }

      world.sync();

      double runtime = get_time();

      // TODO: Add possibly required additional parameters
      k_means(niters, points, centroids, result, local_size, k, world);
      world.sync();

      runtime = get_time() - runtime;

      if (world.rank() == 0) {
          printf("Time Elapsed: %f s\n", runtime);
          // Verify the results by visualization. Result contains space for the
          // position of the centroids of the initial configuration and at every
          // iteration of the algorithm. For debugging purposes, the array is set to
          // values outside the domain.
          write_result("result.out", niters, result, k);
      }

      free(result);

  });
  
  return EXIT_SUCCESS;
}
