module switch intel gcc/8
module load intel
